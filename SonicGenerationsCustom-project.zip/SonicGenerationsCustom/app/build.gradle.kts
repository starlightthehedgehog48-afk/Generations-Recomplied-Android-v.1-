plugins {
    id("com.android.application")
}

android {
    namespace = "com.sonicgenerations.custom"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sonicgenerations.custom"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
