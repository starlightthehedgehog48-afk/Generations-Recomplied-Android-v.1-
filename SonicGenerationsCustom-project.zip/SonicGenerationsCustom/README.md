# Sonic Generations Custom Android Menu

A fan-made Android WebView app containing a blue/yellow Sonic-themed menu, working menu navigation, character-selection demo, settings toggles, an Xbox-style touch-control preview, and a game-file picker demo.

## Important limitation
This project is a **menu prototype**, not a Sonic Generations game engine or port. Selecting a game file does not run it. Actual gameplay needs a compatible, legally obtained game engine/port and supported data format. It does not modify the supplied Unleashed Recomp APK.

## Build online with GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder (the files inside `SonicGenerationsCustom`, not the outer folder).
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Select **Build Android APK** and press **Run workflow** (or push to the `main` branch).
4. When the run completes, open it and download the `SonicGenerationsCustom-debug-apk` artifact.
5. Extract the downloaded ZIP and install `app-debug.apk` on your Android device. Android may ask you to allow installs from your browser/file manager.

The workflow builds a debug APK with Android SDK platform 35 and Gradle 8.9.
